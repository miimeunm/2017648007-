#define MAXLINE 100

char line[MAXLINE];
char longest[MAXLINE];
