#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>


/*
void rwx(file_mode){
	
		if (S_ISDIR(file_mode)){
			printf("d");
		}
		else
			printf("-");	
		if (file_mode & S_IRUSR){
			printf("r");
		}
		else
			printf("-");
		
		if (file_mode & S_IWUSR){
			printf("w");
		}
		else
			printf("-");
		
		if (file_mode & S_IXUSR){
			printf("x");
		}
		else
			printf("-"); 
		
		if (file_mode & S_IRGRP){
			printf("r");
		}
		else
			printf("-");
		
		if (file_mode & S_IWGRP){
			printf("w");
		}
		else
			printf("-");
		
		if(file_mode & S_IXGRP)
		{
			printf("x");
		}
		else
			printf("-"); 
		
		if (file_mode & S_IROTH)
		{
			printf("r");
		}
		else
			printf("-");
		
		if (file_mode & S_IWOTH)
		{
			printf("w");
		}
		else
			printf("-");
		
		if(file_mode & S_IXOTH)
		{
			printf("x");
		}
		else
			printf("-");

		printf(" ");
}
*/


void ls_a(struct dirent *p){

	DIR *dir;
	dir = opendir(".");
	while(p = readdir(dir)){
		printf("%s ", p->d_name);
	}
	printf("\n");
	closedir(dir);
}

void ls_l(struct dirent *p){
	
	DIR *dir;
	dir = opendir(".");

	struct stat buf;
	mode_t file_mode;
	struct passwd *pwd;
	struct group *grp;


	while(p = readdir(dir)){

/*
			file_mode = buf.st_mode;
			rwx(file_mode);

*/
			printf("%ld ", buf.st_nlink);

			pwd = getpwuid(buf.st_uid);
			printf("%s ", pwd->pw_name);
			grp = getgrgid(buf.st_gid);
			printf("%s ", grp->gr_name);
			printf("%ld ", buf.st_size);

			if(p->d_ino != 0) printf("%s \n", p->d_name);
		

	}

	printf("\n");
	closedir(dir);

}

void ls_i(struct dirent *p){

	DIR *dir;

	dir = opendir(".");

	while(p = readdir(dir)){ 
		printf("%6lu %s ", p->d_ino, p->d_name);
	}
	printf("\n");
	closedir(dir);
}

int main(int argc, char **argv){

	DIR *dir;
	int opt;
	struct dirent *p;
	int check = 0;

	while((opt = getopt(argc, argv, "lia")) != -1){
		switch(opt){
/*
			case 'l' : ls_l(dp,p); break;
			case 'i' : ls_i(p); break;
			case 'a' : ls_a(p); break;
			default : ls(p); break;
*/
			case 'l' : ls_l(p); check = 1; break;
			case 'i' : ls_i(p); check = 1; break;
			case 'a' : ls_a(p); check = 1; break;
			default : check = 0; break; 
		}
	}

	if(check == 0){
		dir = opendir(".");
		while((p = readdir(dir)) != NULL){
			if(strcmp(p->d_name,".") != 0 && strcmp(p->d_name, "..") != 0)
				printf("%s ", p->d_name);
			}	

		printf("\n");
		closedir(dir);
	}
	return 0;
}




	
